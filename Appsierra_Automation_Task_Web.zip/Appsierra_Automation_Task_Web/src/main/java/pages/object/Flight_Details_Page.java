package pages.object;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.Base;

public class Flight_Details_Page extends Base {

	@FindBy(css="[class='fltHpyOnwrdWrp']>div>ul>li#PRICE")
	WebElement sortPriceOnwrdJrny;

	@FindBy(css="[class='fltHpyOnwrdWrp']>div>ul>li#PRICE>span>i")
	WebElement sortIconHighPriceOnwrdJrny;

	@FindBy(css="[class='fltHpyRtrnWrp']>div>ul>li#PRICE")
	WebElement sortPriceRtrnJrny;

	@FindBy(css="[class='fltHpyRtrnWrp']>div>ul>li#PRICE>span>i")
	WebElement sortIconHighPriceRtrnJrny;

	@FindBy(css="[class='fltHpyOnwrdWrp']>div[class='marginB10']>div")
	WebElement onwrdFlightID;

	@FindBy(css="[class='fltHpyRtrnWrp']>div[class='marginB10']>div")
	WebElement returnFlightID;

	@FindBy(id="NAV42#:SG8429SG415radioBtn")
	WebElement flightRadioBtn;

	@FindBy(css="input[type='button'][value='BOOK']")
	WebElement flightBookBtn;

	//Initialize Page Objects
	public Flight_Details_Page() {
		PageFactory.initElements(driver, this);
	}

	//Click on Sort Icon for Departure Flight
	public void clickSortPriceOnwardJrny() {
		explicitWaitCondition(5, sortPriceOnwrdJrny);
		sortPriceOnwrdJrny.click();
	}

	//Click on Sort Icon for Return Flight
	public void clickSortPriceRtrnJrny() {
		explicitWaitCondition(5, sortPriceRtrnJrny);
		sortPriceRtrnJrny.click();
	}

	//Get Onward Flight ID
	public String getOnwrdFlightID() {
		String flightID=onwrdFlightID.getAttribute("data-cy");
		String[] trimmedText = flightID.split("_");
		return trimmedText[1];
	}

	//Get Return Flight ID
	public String getRtrnFlightID() {
		String flightID=returnFlightID.getAttribute("data-cy");
		String[] trimmedText = flightID.split("_");
		return trimmedText[1];
	}

	//Select Flight
	public void selectFlight(String flightID) {
		WebElement flightRadioBtn=driver.findElement(By.cssSelector("[class='custRad']>label[for='"+flightID+"radioBtn']"));
		Actions action = new Actions(driver);
		action.moveToElement(flightRadioBtn).build();
		explicitWaitCondition(5, flightRadioBtn);
		action.click(flightRadioBtn);
		action.perform();
	}

	//Click on Book Flight Button
	public void clickFlightBookBtn() {
		flightBookBtn.click();
	}

	//Validate for Sort Icon
	public boolean displayChangeSortIcon() {
		try {

			if(sortIconHighPriceOnwrdJrny.isDisplayed()) {
				System.out.println("Flight Price Sorted From High to Low For Onward Journey");
				return true;
			}else {
				System.out.println("Flight Price Not Sorted From High to Low");
				return false;
			}

		} catch (NoSuchElementException e) {
			System.out.println("Flight Price Not Sorted From High to Low");
			return false;
		}
	}

	//Validate for Displaying Flight Details
	public boolean displayBookBtnOnFlightDetails() {
		try {
			explicitWaitCondition(5, flightBookBtn);
			flightBookBtn.isDisplayed();
			System.out.println("Search Flight Details Displayed");
			return true;

		} catch (NoSuchElementException e) {
			System.out.println("Search Flight Details Not Displayed");
			return false;
		}
	}

}
