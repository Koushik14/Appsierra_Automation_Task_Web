package pages.object;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import base.Base;

public class Flight_Review_Page extends Base{

	@FindBy(id="Adulttitle1")
	WebElement adultTitleDropDown;

	@FindBy(id="AdultfirstName1")
	WebElement firstName;

	@FindBy(id="AdultlastName1")
	WebElement lastName;

	@FindBy(id="email")
	WebElement emailID;

	@FindBy(id="mobile")
	WebElement mobileNumber;

	@FindBy(css="[class='button orange col-md-3 fr large dF justifyCenter min37']")
	WebElement proceedBtn;

	@FindBy(id="risk-trip")
	WebElement riskTripRadioBtn;

	//Initialize Page Objects
	public Flight_Review_Page() {
		PageFactory.initElements(driver, this);
	}

	//Select Travel Protection Option
	public void clickTravelProtcOption() {
		explicitWaitCondition(5, riskTripRadioBtn);
		riskTripRadioBtn.click();
	}

	//Select Adult Title
	public void selectTitle(String adTitle) {
		Actions action = new Actions(driver);
		action.moveToElement(adultTitleDropDown).build();
		adultTitleDropDown.click();
		action.perform();
		Select adultTitle= new Select(adultTitleDropDown);
		adultTitle.selectByValue(adTitle);
	}

	//Enter First Name
	public void enterFirstName(String fName) {
		firstName.sendKeys(fName);
	}

	//Enter Last Name
	public void enterLastName(String lName) {
		lastName.sendKeys(lName);
	}

	//Enter Email
	public void enterEmail(String userEmail) {
		emailID.sendKeys(userEmail);
	}

	//Enter Mobile Number
	public void enterMobileNumber(String mobNumb) {
		mobileNumber.sendKeys(mobNumb);
	}

	//Click on Proceed Button
	public void clickProceedBtn() {
		proceedBtn.click();
	}

}
