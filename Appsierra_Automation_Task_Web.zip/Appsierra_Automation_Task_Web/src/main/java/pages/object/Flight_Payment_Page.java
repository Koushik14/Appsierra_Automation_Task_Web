package pages.object;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.Base;

public class Flight_Payment_Page extends Base {

	@FindBy(id="tab_wallet")
	WebElement walletPaymentType;

	@FindBy(css="label[for='amazonpay'")
	WebElement walletAmazonPay;

	//Initialize Page Objects
	public Flight_Payment_Page() {
		PageFactory.initElements(driver, this);
	}

	//Click on Payment Type
	public void clickPaymentType() {
		Actions action = new Actions(driver);
		action.moveToElement(walletPaymentType).build();
		explicitWaitCondition(10, walletPaymentType);
		walletPaymentType.click();
		action.perform();
	}

	//validate Wallet Payment Option
	public boolean displayAmazonPayOption() {
		try {
			explicitWaitCondition(5, walletAmazonPay);
			walletAmazonPay.isDisplayed();
			System.out.println("Amazon Wallet Pay Option Displayed");
			return true;

		} catch (NoSuchElementException e) {
			System.out.println("Amazon Wallet Pay Option Not Displayed");
			return false;
		}
	}
}
