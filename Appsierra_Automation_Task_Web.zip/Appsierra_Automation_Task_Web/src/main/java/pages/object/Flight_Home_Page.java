package pages.object;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.Base;

public class Flight_Home_Page extends Base {

	@FindBy(id="roundTrip")
	WebElement roundTripSpan;

	@FindBy(id="gosuggest_inputSrc")
	WebElement inputFrom;

	@FindBy(id="gosuggest_inputDest")
	WebElement inputDestination;

	@FindBy(id="react-autosuggest-1")
	WebElement autoSuggestList;

	@FindBy(id="departureCalendar")
	WebElement departureCalendar;

	@FindBy(css="[class='DayPicker-Day'][aria-disabled='false']>div")
	WebElement selectTravelDate;

	@FindBy(id="returnCalendar")
	WebElement returnCalendar;

	@FindBy(css="[class='DayPicker-Day'][aria-disabled='false']>div")
	WebElement selectDate;

	@FindBy(id="fare_20200820")
	WebElement selDate;

	@FindBy(id="gi_search_btn")
	WebElement searchBtn;

	//Initialize Page Objects
	public Flight_Home_Page() {
		PageFactory.initElements(driver, this);
	}

	//Click on RoundTrip Option
	public void clickRoundTrip() {
		explicitWaitCondition(5, roundTripSpan);
		roundTripSpan.click();
	}

	//Enter From Destination
	public void enterFromDestination(String fromCity) {
		explicitWaitCondition(5, inputFrom);
		inputFrom.sendKeys(fromCity);
		explicitWaitCondition(5, autoSuggestList);
		inputFrom.sendKeys(Keys.ARROW_DOWN);
		inputFrom.sendKeys(Keys.ENTER);
	}

	//Enter To Destination
	public void enterToDestination(String toCity) {
		explicitWaitCondition(5, inputDestination);
		inputDestination.sendKeys(toCity);
		explicitWaitCondition(5, autoSuggestList);
		inputDestination.sendKeys(Keys.ARROW_DOWN);
		inputDestination.sendKeys(Keys.ENTER);
	}

	//Click on Departure Date
	public void clickOnDepDate() {
		departureCalendar.click();
	}

	//Click on Return Date
	public void clickOnRetDate() {
		returnCalendar.click();
	}

	//Click on Search Button
	public void clickOnSearchBtn() {
		searchBtn.click();
	}

	//Select Date
	public void selectDate(String date) {
		driver.findElement(By.id("fare_"+date+"")).click();
	}

	//Select from auto suggest lists
	public void autosuggestCityNames(String textToSelect) {
		List<WebElement> autosug= driver.findElements(By.id("react-autosuggest-1"));
		for(WebElement option : autosug){
			System.out.println(option);
			if(option.getText().contains(textToSelect)) {
				System.out.println("Trying to select: "+textToSelect);
				option.sendKeys(Keys.ARROW_DOWN);
				option.sendKeys(Keys.ENTER);
				break;
			}
		}
	}

}
