package pages.object;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.Base;

public class Flight_Seat_Select_Page extends Base {

	@FindBy(css=".button.bkPgPrcd")
	WebElement proceedToPayment;

	@FindBy(css="button.blue.large.fb.padLR30")
	WebElement popOverlayOkBtn;

	//Initialize Page Objects
	public Flight_Seat_Select_Page() {
		PageFactory.initElements(driver, this);
	}

	//Click on Proceed to Payment Button
	public void clickProceedToPayment() {
		Actions action = new Actions(driver);
		action.moveToElement(proceedToPayment).build();
		explicitWaitCondition(5, proceedToPayment);
		proceedToPayment.click();
		action.perform();
	}

	//Click OK on Covid19 Message OverLay
	public void clickPopOverlayOkBtn() {
		try {
			explicitWaitCondition(20, popOverlayOkBtn);
			popOverlayOkBtn.click();
		} catch (NoSuchElementException e) { System.out.println(e.getMessage()); }

	}

}
