package base;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


public class Base {
	
	public static WebDriver driver;
	public static Properties prop;
	String currDir= System.getProperty("user.dir");
	
	public Base(){
		try{
			prop = new Properties();
			FileInputStream configFile = new FileInputStream(System.getProperty("user.dir") 
					+ "\\src\\main\\java\\config\\config.properties"); 
			prop.load(configFile);
		} catch (FileNotFoundException e){
			e.printStackTrace();
		} catch (IOException e){
			e.printStackTrace();
		}
	}
	
	public static void initialization(String url){
		String browserName=prop.getProperty("browser");
		if(browserName.equals("chrome")){
			System.setProperty("webdriver.chrome.driver", "driver/chromedriver.exe" );
			driver = new ChromeDriver();	
			
		}else if(browserName.equals("firefox")){
			System.setProperty("webdriver.gecko.driver", "driver/chromedriver.exe" );
			driver = new FirefoxDriver();
	}
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.get(url);
		}
	
	public static void closeBrowser(){
		driver.quit();
	}
	
	public static void explicitWaitCondition(long time, WebElement element) {
		WebDriverWait wait = new WebDriverWait(driver, time);
		wait.until(ExpectedConditions.visibilityOf(element));
	}
}
