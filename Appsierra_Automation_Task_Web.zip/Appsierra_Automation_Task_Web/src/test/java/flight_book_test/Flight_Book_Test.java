package flight_book_test;

import static org.testng.Assert.assertTrue;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import base.Base;
import pages.object.Flight_Details_Page;
import pages.object.Flight_Home_Page;
import pages.object.Flight_Payment_Page;
import pages.object.Flight_Review_Page;
import pages.object.Flight_Seat_Select_Page;

public class Flight_Book_Test extends Base{

	Flight_Home_Page flightHomePage;
	Flight_Details_Page flightDetailsPage;
	Flight_Review_Page flightReviewPage;
	Flight_Seat_Select_Page flightSeatSelectPage;
	Flight_Payment_Page flightPaymentPage;

	//Initialize Browser and Create Page Objects of Pages Class
	@BeforeMethod
	public void setUP() {
		initialization("https://www.goibibo.com/");
		flightHomePage = new Flight_Home_Page();
		flightDetailsPage = new Flight_Details_Page();
		flightReviewPage = new Flight_Review_Page();
		flightSeatSelectPage = new Flight_Seat_Select_Page();
		flightPaymentPage = new Flight_Payment_Page();
	}

	//Quit Browser
	@AfterMethod
	public void tearDown() {
		driver.quit();
	}
	
	//Search Flight
	@Parameters({"fromDesti","toDesti","travelDate","returnDate"})
	@Test (priority=1)
	public void searchFlight(String fromDesti, String toDesti, String travelDate, String returnDate) {
		flightHomePage.clickRoundTrip();
		flightHomePage.enterFromDestination(fromDesti);
		flightHomePage.enterToDestination(toDesti);
		flightHomePage.clickOnDepDate(); 
		flightHomePage.selectDate(travelDate);
		flightHomePage.selectDate(returnDate);
		flightHomePage.clickOnSearchBtn();
		boolean flightBookBtn=flightDetailsPage.displayBookBtnOnFlightDetails();
		assertTrue(flightBookBtn);
	}
	
	//Sorting Flight Price From High to Low
	@Parameters({"fromDesti","toDesti","travelDate","returnDate"})
	@Test (priority=2)
	public void sortFlightPrice(String fromDesti, String toDesti, String travelDate, String returnDate) {
		flightHomePage.clickRoundTrip();
		flightHomePage.enterFromDestination(fromDesti);
		flightHomePage.enterToDestination(toDesti);
		flightHomePage.clickOnDepDate(); 
		flightHomePage.selectDate(travelDate);
		flightHomePage.selectDate(returnDate);
		flightHomePage.clickOnSearchBtn();
		flightDetailsPage.clickSortPriceOnwardJrny();
		boolean sortIconOnwrd=flightDetailsPage.displayChangeSortIcon();
		assertTrue(sortIconOnwrd);
		flightDetailsPage.clickSortPriceRtrnJrny();
		boolean sortIconRtrn=flightDetailsPage.displayChangeSortIcon();
		assertTrue(sortIconRtrn);
	}
	
	//Book Flights With High Price
	@Parameters({"fromDesti","toDesti","travelDate","returnDate","adTitle","fName","lName","userEmail","mobNumber"})
	@Test (priority=3)
	public void bookFlight(String fromDesti, String toDesti, String travelDate, String returnDate, String adTitle, String fName, String lName, String  userEmail, String mobNumber) {
		flightHomePage.clickRoundTrip();
		flightHomePage.enterFromDestination(fromDesti);
		flightHomePage.enterToDestination(toDesti);
		flightHomePage.clickOnDepDate(); 
		flightHomePage.selectDate(travelDate);
		flightHomePage.selectDate(returnDate);
		flightHomePage.clickOnSearchBtn();
		flightDetailsPage.clickSortPriceOnwardJrny();
		String onwrdFlightName=flightDetailsPage.getOnwrdFlightID();
		System.out.println(onwrdFlightName);
		flightDetailsPage.selectFlight(onwrdFlightName);
		flightDetailsPage.clickSortPriceRtrnJrny();
		String rtrnFlightName=flightDetailsPage.getRtrnFlightID();
		flightDetailsPage.selectFlight(rtrnFlightName);
		flightDetailsPage.clickFlightBookBtn();
		flightReviewPage.clickTravelProtcOption();
		flightReviewPage.selectTitle(adTitle);
		flightReviewPage.enterFirstName(fName);
		flightReviewPage.enterLastName(lName);
		flightReviewPage.enterEmail(userEmail);
		flightReviewPage.enterMobileNumber(mobNumber);
		flightReviewPage.clickProceedBtn();
		flightSeatSelectPage.clickPopOverlayOkBtn();
		flightSeatSelectPage.clickProceedToPayment();
		flightPaymentPage.clickPaymentType();
		boolean amazonPay=flightPaymentPage.displayAmazonPayOption();
		assertTrue(amazonPay);
	}






}
